<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html lang="en"><!-- InstanceBegin template="/Templates/cn-content-page.dwt" codeOutsideHTMLIsLocked="false" -->

<head>
<meta http-equiv="Content-Language" content="en-CA">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<!-- InstanceBeginEditable name="doctitle" -->
<title></title>
<!-- InstanceEndEditable -->

<!-- InstanceBeginEditable name="metaInformation" -->
<meta name="keywords" content="">
<meta name="description" content="">
<!-- InstanceEndEditable -->

<meta name="author" content="">
<meta name="copyright" content="&copy; University of Ottawa">

<?php include("http://web5.uottawa.ca/assets-templates/inc/head.html"); ?>

<!-- theme -->
<link type="text/css" rel="stylesheet" media="screen" href="http://web5.uottawa.ca/assets-templates/themes/08/main.css">
<!-- site-specific style sheet -->
<link type="text/css" rel="stylesheet" media="screen" href="/assets/css/section-header-cn.css">
<link type="text/css" rel="stylesheet" media="screen" href="/assets/css/main.css">

<!-- include page tools -->
<script type="text/javascript" src="http://web5.uottawa.ca/assets-templates/js/print.js"></script>
<script type="text/javascript" src="http://web5.uottawa.ca/assets-templates/js/send-to-friend.js"></script>

<!-- InstanceBeginEditable name="head" -->
<!-- page variables -->
<script type="text/javascript">
<!--
var expandNavSection = "section";
-->
</script><!-- /page variables -->

<style type="text/css">
<!--
.excel1 {
padding-top:1px;
padding-right:1px;
padding-left:1px;
color:windowtext;
font-size:12.0pt;
font-weight:400;
font-style:normal;
text-decoration:none;
font-family:宋体;
text-align:general;
vertical-align:middle;
border:none;
white-space:nowrap;
}
.excel4 {
padding-top:1px;
padding-right:1px;
padding-left:1px;
color:windowtext;
font-size:9.0pt;
font-weight:700;
font-style:normal;
text-decoration:none;
font-family:宋体;
text-align:left;
vertical-align:middle;
border:none;
white-space:nowrap;
}
.excel5 {
padding-top:1px;
padding-right:1px;
padding-left:1px;
color:black;
font-size:9.0pt;
font-weight:400;
font-style:normal;
text-decoration:none;
font-family:宋体;
text-align:general;
vertical-align:middle;
border:none;
white-space:nowrap;
}
.excel3 {
padding-top:1px;
padding-right:1px;
padding-left:1px;
color:windowtext;
font-size:9.0pt;
font-weight:400;
font-style:normal;
text-decoration:none;
font-family:宋体;
text-align:left;
vertical-align:middle;
border:none;
white-space:nowrap;
}
.excel2 {
padding-top:1px;
padding-right:1px;
padding-left:1px;
color:windowtext;
font-size:11.0pt;
font-weight:700;
font-style:normal;
text-decoration:none;
font-family:宋体;
text-align:center;
vertical-align:middle;
border:none;
white-space:nowrap;
}
-->
</style>
<style type="text/css">
<!--
.excel6 {
padding-top:1px;
padding-right:1px;
padding-left:1px;
color:windowtext;
font-size:12.0pt;
font-weight:400;
font-style:normal;
text-decoration:none;
font-family:宋体;
text-align:general;
vertical-align:middle;
border:none;
white-space:nowrap;
}
.excel7 {
padding-top:1px;
padding-right:1px;
padding-left:1px;
color:windowtext;
font-size:12.0pt;
font-weight:700;
font-style:normal;
text-decoration:none;
font-family:宋体;
text-align:center;
vertical-align:middle;
border:none;
white-space:nowrap;
}
.excel8 {
padding-top:1px;
padding-right:1px;
padding-left:1px;
color:windowtext;
font-size:11.0pt;
font-weight:700;
font-style:normal;
text-decoration:none;
font-family:宋体;
text-align:center;
vertical-align:middle;
border:none;
white-space:nowrap;
}
.excel13 {
padding-top:1px;
padding-right:1px;
padding-left:1px;
color:windowtext;
font-size:9.0pt;
font-weight:700;
font-style:normal;
text-decoration:none;
font-family:宋体;
text-align:general;
vertical-align:middle;
border:none;
white-space:nowrap;
}
.excel11 {
padding-top:1px;
padding-right:1px;
padding-left:1px;
color:windowtext;
font-size:9.0pt;
font-weight:400;
font-style:normal;
text-decoration:none;
font-family:宋体;
text-align:general;
vertical-align:middle;
border:none;
white-space:nowrap;
}
.excel12 {
padding-top:1px;
padding-right:1px;
padding-left:1px;
color:black;
font-size:9.0pt;
font-weight:400;
font-style:normal;
text-decoration:none;
font-family:宋体;
text-align:general;
vertical-align:middle;
border:none;
white-space:nowrap;
}
.font5 {
color:black;
font-size:9.0pt;
font-weight:400;
font-style:normal;
text-decoration:none;
font-family:Arial, sans-serif;
}
.excel9 {
padding-top:1px;
padding-right:1px;
padding-left:1px;
color:windowtext;
font-size:9.0pt;
font-weight:400;
font-style:normal;
text-decoration:none;
font-family:宋体;
text-align:left;
vertical-align:middle;
border:none;
white-space:nowrap;
}
.excel10 {
padding-top:1px;
padding-right:1px;
padding-left:1px;
color:windowtext;
font-size:9.0pt;
font-weight:700;
font-style:normal;
text-decoration:none;
font-family:宋体;
text-align:left;
vertical-align:middle;
border:none;
white-space:nowrap;
}
.excel14 {
padding-top:1px;
padding-right:1px;
padding-left:1px;
color:black;
font-size:11.0pt;
font-weight:700;
font-style:normal;
text-decoration:none;
font-family:宋体;
text-align:center;
vertical-align:middle;
border:none;
white-space:nowrap;
}
.excel15 {
padding-top:1px;
padding-right:1px;
padding-left:1px;
color:black;
font-size:9.0pt;
font-weight:700;
font-style:normal;
text-decoration:none;
font-family:宋体;
text-align:general;
vertical-align:middle;
border:none;
white-space:nowrap;
}
.excel16 {
padding-top:1px;
padding-right:1px;
padding-left:1px;
color:windowtext;
font-size:9.0pt;
font-weight:700;
font-style:normal;
text-decoration:none;
font-family:宋体;
text-align:left;
vertical-align:middle;
border:none;
white-space:nowrap;
}
-->
</style>
<!-- InstanceEndEditable -->
</head>

<body class="en">

<div id="main-container" class="content-page">
<!-- InstanceBeginEditable name="pageLinks" -->
	<ul id="page-links">
		<li><a id="skip-to-content" href="#main-content">Skip to content</a></li>
		<li><a id="skip-to-localnav" href="#local-nav">Skip to links</a></li>
		<li><a id="ch-lang-url" href="http://www.juriglobe.uottawa.ca/index.php" rel="alternate" lang="fr" hreflang="fr">Français</a></li>
		<li><a id="section-home" href="http://www.juriglobe.uottawa.ca/eng/index.php">Return to the home page</a></li>
	</ul>
<!-- InstanceEndEditable -->
	<!-- /#page-links -->

<?php include("http://web5.uottawa.ca/assets-templates/inc/banner-en.html"); ?>

<div id="section-container">

<!-- InstanceBeginEditable name="sectionHeader" -->
<?php virtual("/assets/inc/section-header-cn.html"); ?>
<!-- InstanceEndEditable -->

<div id="page-tools">
<div id="quickpicks">
<ul>
	<?php virtual("/assets/inc/quickpicks-en.html"); ?>
	<?php include("http://web5.uottawa.ca/assets-templates/inc/quickpicks-en.html"); ?>
</ul>
</div><!-- /#quickpicks -->
</div>
<!-- /#page-tools -->

<div id="section-details">
	<!-- InstanceBeginEditable name="Navigation" -->
	<?php virtual("/assets/inc/nav-cn.html"); ?>
	
	<!-- InstanceEndEditable -->
</div>

<div id="main-content">
<?php 
echo "<h4 align=right>";
echo "<a href=", str_replace("/chi/","/eng/",$_SERVER["PHP_SELF"]),">English</a> " ;
echo "<a href=", str_replace("/chi/","/fra/",$_SERVER["PHP_SELF"]),">Français</a> " ;
echo "<a href=", str_replace("/chi/","/esp/",$_SERVER["PHP_SELF"]),">Español</a> " ;
echo "<a href=", str_replace("/chi/","/rus/",$_SERVER["PHP_SELF"]),">Русский</a> " ;
echo "<a href=", str_replace("/chi/","/ara/",$_SERVER["PHP_SELF"]),">عربي</a> " ;
echo "</h4><hr>";
?>
	<!-- InstanceBeginEditable name="mainContent" -->
<h2>语言和普通法系</h2>
<table cellspacing="3" cellpadding="3">
  <tr>
    <td><div align="center"><u><strong>单一制普通法系：</strong></u></div></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td><strong>英语</strong></td>
  </tr>
  <tr>
    <td>安圭拉岛（英属）</td>
  </tr>
  <tr>
    <td>安提瓜和巴布达</td>
  </tr>
  <tr>
    <td>澳大利亚</td>
  </tr>
  <tr>
    <td>巴哈马群岛</td>
  </tr>
  <tr>
    <td>巴巴多斯</td>
  </tr>
  <tr>
    <td>伯利兹</td>
  </tr>
  <tr>
    <td>百慕大群岛（英属）</td>
  </tr>
  <tr>
    <td>加拿大（不包括魁北克）</td>
  </tr>
  <tr>
    <td>开曼群岛（英属）</td>
  </tr>
  <tr>
    <td>库克群岛（新属）</td>
  </tr>
  <tr>
    <td>多米尼克</td>
  </tr>
  <tr>
    <td>美国（不包括路易斯安那）</td>
  </tr>
  <tr>
    <td>斐济</td>
  </tr>
  <tr>
    <td>南乔治亚岛与南桑威奇岛（英属）</td>
  </tr>
  <tr>
    <td>直布罗陀（英属）</td>
  </tr>
  <tr>
    <td>格林纳达</td>
  </tr>
  <tr>
    <td>关岛（美属）</td>
  </tr>
  <tr>
    <td>夏威夷（美属）</td>
  </tr>
  <tr>
    <td>爱尔兰</td>
  </tr>
  <tr>
    <td>北爱尔兰（英国）</td>
  </tr>
  <tr>
    <td>牙买加  </td>
  </tr>
  <tr>
    <td>基里巴斯</td>
  </tr>
  <tr>
    <td>马尔维纳斯群岛（英属）</td>
  </tr>
  <tr>
    <td>马恩岛 （英属）</td>
  </tr>
  <tr>
    <td>马里亚纳群岛（美国）</td>
  </tr>
  <tr>
    <td>马绍尔群岛</td>
  </tr>
  <tr>
    <td>蒙塞瑞特（英属）</td>
  </tr>
  <tr>
    <td>瑙鲁</td>
  </tr>
  <tr>
    <td>纽埃（新属）</td>
  </tr>
  <tr>
    <td>诺福克岛（澳属）</td>
  </tr>
  <tr>
    <td>新西兰</td>
  </tr>
  <tr>
    <td>帕劳</td>
  </tr>
  <tr>
    <td>比特凯恩（英属）</td>
  </tr>
  <tr>
    <td>英国（不包括苏格兰）</td>
  </tr>
  <tr>
    <td>圣基茨和尼维斯</td>
  </tr>
  <tr>
    <td>圣赫勒拿岛（英属）</td>
  </tr>
  <tr>
    <td>圣文森特和格林那丁斯</td>
  </tr>
  <tr>
    <td>美属萨摩亚</td>
  </tr>
  <tr>
    <td>英属南极领地</td>
  </tr>
  <tr>
    <td>英属印度洋领地</td>
  </tr>
  <tr>
    <td>托克劳群岛（新属） </td>
  </tr>
  <tr>
    <td>汤加</td>
  </tr>
  <tr>
    <td>特立尼达和多巴哥</td>
  </tr>
  <tr>
    <td>托克斯和凯科斯群岛（英属）</td>
  </tr>
  <tr>
    <td>图瓦卢</td>
  </tr>
  <tr>
    <td>美属维尔京群岛</td>
  </tr>
  <tr>
    <td>英属维尔京群岛</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td><strong>查莫罗语</strong></td>
  </tr>
  <tr>
    <td>关岛（美属）</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td><strong>法语</strong></td>
  </tr>
  <tr>
    <td>加拿大（不包括魁北克）</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td><strong>夏威夷语</strong></td>
  </tr>
  <tr>
    <td>夏威夷（美属）</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td><strong>爱尔兰语</strong></td>
  </tr>
  <tr>
    <td>爱尔兰 </td>
  </tr>
  <tr>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td><strong>基里巴斯语</strong></td>
  </tr>
  <tr>
    <td>基里巴斯</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td><strong>马恩语</strong></td>
  </tr>
  <tr>
    <td>马恩岛 （英属）</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td><strong>瑙鲁语</strong></td>
  </tr>
  <tr>
    <td>瑙鲁</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td><strong>纽埃语</strong></td>
  </tr>
  <tr>
    <td>纽埃（新属）</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td><strong>托克劳语</strong></td>
  </tr>
  <tr>
    <td>托克劳群岛（新属） </td>
  </tr>
  <tr>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td><strong>汤加语</strong></td>
  </tr>
  <tr>
    <td>汤加</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td><strong>图瓦卢语</strong></td>
  </tr>
  <tr>
    <td>图瓦卢</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td><div align="center"><u><strong>民法和普通法混合法系：</strong></u></div></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td><strong>南非荷兰语</strong></td>
  </tr>
  <tr>
    <td>南非 </td>
  </tr>
  <tr>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td><strong>英语</strong></td>
  </tr>
  <tr>
    <td>南非</td>
  </tr>
  <tr>
    <td>博茨瓦纳</td>
  </tr>
  <tr>
    <td>苏格兰（英属）</td>
  </tr>
  <tr>
    <td>圭亚那</td>
  </tr>
  <tr>
    <td>路易斯安那（美属）</td>
  </tr>
  <tr>
    <td>马耳他</td>
  </tr>
  <tr>
    <td>毛里求斯</td>
  </tr>
  <tr>
    <td>纳米比亚</td>
  </tr>
  <tr>
    <td>菲律宾</td>
  </tr>
  <tr>
    <td>波多黎各岛（美属）</td>
  </tr>
  <tr>
    <td>魁北克（加属）</td>
  </tr>
  <tr>
    <td>圣卢西</td>
  </tr>
  <tr>
    <td>塞舌尔</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td><strong>克里奥尔语</strong></td>
  </tr>
  <tr>
    <td>塞舌尔</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td><strong>西班牙语</strong></td>
  </tr>
  <tr>
    <td>波多黎各岛（美属）</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td><strong>法语</strong></td>
  </tr>
  <tr>
    <td>毛里求斯</td>
  </tr>
  <tr>
    <td>魁北克（加属）</td>
  </tr>
  <tr>
    <td>塞舌尔</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td><strong>希腊语</strong></td>
  </tr>
  <tr>
    <td>塞浦路斯</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td><strong>马耳他语</strong></td>
  </tr>
  <tr>
    <td>马耳他 </td>
  </tr>
  <tr>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td><strong>他加禄语（菲律宾语）</strong></td>
  </tr>
  <tr>
    <td>菲律宾</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td><strong>土耳其语</strong></td>
  </tr>
  <tr>
    <td>塞浦路斯</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td><div align="center"><u><strong>民法、习惯法和普通法混合法系：</strong></u></div></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td><strong>英语</strong></td>
  </tr>
  <tr>
    <td>喀麦隆</td>
  </tr>
  <tr>
    <td>莱索托</td>
  </tr>
  <tr>
    <td>瓦努阿图</td>
  </tr>
  <tr>
    <td>津巴布韦</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td><strong>比斯拉马语</strong></td>
  </tr>
  <tr>
    <td>瓦努阿图</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td><strong>僧伽罗语</strong></td>
  </tr>
  <tr>
    <td>斯里兰卡</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td><strong>法语</strong></td>
  </tr>
  <tr>
    <td>喀麦隆</td>
  </tr>
  <tr>
    <td>瓦努阿图</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td><strong>塞苏陀语</strong></td>
  </tr>
  <tr>
    <td>莱索托</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td><strong>泰米尔语</strong></td>
  </tr>
  <tr>
    <td>斯里兰卡</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td><div align="center"><u><strong>普通法和穆斯林法混合法系：</strong></u></div></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td><strong>英语</strong></td>
  </tr>
  <tr>
    <td>巴基斯坦</td>
  </tr>
  <tr>
    <td>新加坡</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td><strong>阿拉伯语</strong></td>
  </tr>
  <tr>
    <td>苏丹</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td><strong>孟加拉语</strong></td>
  </tr>
  <tr>
    <td>孟加拉国</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td><strong>汉语</strong></td>
  </tr>
  <tr>
    <td>新加坡</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td><strong>马来语</strong></td>
  </tr>
  <tr>
    <td>新加坡</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td><strong>乌尔都语</strong></td>
  </tr>
  <tr>
    <td>巴基斯坦 </td>
  </tr>
  <tr>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td><strong>泰米尔语</strong></td>
  </tr>
  <tr>
    <td>新加坡</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td><div align="center"><u><strong>普通法和习惯法混合法系：</strong></u></div></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td><strong>英语</strong></td>
  </tr>
  <tr>
    <td>加纳</td>
  </tr>
  <tr>
    <td>香港（中国）</td>
  </tr>
  <tr>
    <td>利比里亚</td>
  </tr>
  <tr>
    <td>马拉维</td>
  </tr>
  <tr>
    <td>密克罗尼西亚</td>
  </tr>
  <tr>
    <td>乌干达</td>
  </tr>
  <tr>
    <td>巴布亚新几内亚</td>
  </tr>
  <tr>
    <td>所罗门群岛</td>
  </tr>
  <tr>
    <td>萨摩亚</td>
  </tr>
  <tr>
    <td>塞拉利昂</td>
  </tr>
  <tr>
    <td>坦桑尼亚</td>
  </tr>
  <tr>
    <td>赞比亚 </td>
  </tr>
  <tr>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td><strong>缅甸语</strong></td>
  </tr>
  <tr>
    <td>缅甸</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td><strong>汉语</strong></td>
  </tr>
  <tr>
    <td>香港（中国）</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td><strong>宗卡语</strong></td>
  </tr>
  <tr>
    <td>不丹</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td><strong>尼泊尔语</strong></td>
  </tr>
  <tr>
    <td>尼泊尔</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td><strong>萨摩亚语</strong></td>
  </tr>
  <tr>
    <td>萨摩亚</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td><strong>斯瓦希里语</strong></td>
  </tr>
  <tr>
    <td>坦桑尼亚</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td><div align="center"><u><strong>普通法、穆斯林法和习惯法混合法系：</strong></u></div></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td><strong>英语</strong></td>
  </tr>
  <tr>
    <td>文莱</td>
  </tr>
  <tr>
    <td>冈比亚</td>
  </tr>
  <tr>
    <td>印度</td>
  </tr>
  <tr>
    <td>肯尼亚</td>
  </tr>
  <tr>
    <td>尼日利亚</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td><strong>印度语</strong></td>
  </tr>
  <tr>
    <td>印度 </td>
  </tr>
  <tr>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td><strong>马来语</strong></td>
  </tr>
  <tr>
    <td>文莱</td>
  </tr>
  <tr>
    <td>马来西亚</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td><strong>史瓦西里語</strong></td>
  </tr>
  <tr>
    <td>肯尼亚</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td><div align="center"><u><strong>普通法、穆斯林法、民法和习惯法混合法系：</strong></u></div></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td><strong>阿拉伯语</strong></td>
  </tr>
  <tr>
    <td>巴林 </td>
  </tr>
  <tr>
    <td>卡塔尔</td>
  </tr>
  <tr>
    <td>也门</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td><strong>索马里语</strong></td>
  </tr>
  <tr>
    <td>索马里</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td><div align="center"><u><strong>民法、普通法、犹太法和穆斯林法混合法系：</strong></u></div></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td><strong>阿拉伯语</strong></td>
  </tr>
  <tr>
    <td>以色列</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td><strong>希伯来语</strong></td>
  </tr>
  <tr>
    <td>以色列</td>
  </tr>
</table>
<p>&nbsp;</p>
	<!-- InstanceEndEditable -->
</div>

<!-- /#main-content -->
</div><!-- /#section-container -->

<?php include("http://web5.uottawa.ca/assets-templates/inc/footer-en.html"); ?>
<?php include("http://web5.uottawa.ca/assets-templates/inc/footer-contact-default-en.html"); ?>

<div id="last-updated">
Last updated: 
<?php echo date ("Y.m.d", getlastmod()) ?>

</div><!-- /#last-updated -->

</div><!-- /#main-container -->

<?php virtual("/assets/inc/beacons-en.html"); ?>

</body>
<!-- InstanceEnd --></html>
